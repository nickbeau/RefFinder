export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyBWxXYJC1-pTWFtEDf4ezw8MHfXaBGdGB0",
    authDomain: "football-service-37f6d.firebaseapp.com",
    databaseURL: "https://football-service-37f6d.firebaseio.com",
    projectId: "football-service-37f6d",
    storageBucket: "football-service-37f6d.appspot.com",
    messagingSenderId: "772557074985"
  }
};
