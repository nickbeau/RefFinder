export * from './chat/chat.component';
