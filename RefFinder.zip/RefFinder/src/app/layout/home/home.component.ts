import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../../router.animations';
import { AuthService } from '../../shared/service/auth.service';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
    animations: [routerTransition()]
})
export class HomeComponent implements OnInit {
    public alerts: Array<any> = [];
    public sliders: Array<any> = [];

    private companyAuth: boolean;

    private company : string;

    constructor(private afAuth: AuthService, private router: Router) {
      

     /*    this.alerts.push({
            id: 1,
            type: 'success',
            message: `Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Voluptates est animi quibusdam praesentium quam, et perspiciatis,
                consectetur velit culpa molestias dignissimos
                voluptatum veritatis quod aliquam! Rerum placeat necessitatibus, vitae dolorum`
        }, {
            id: 2,
            type: 'warning',
            message: `Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Voluptates est animi quibusdam praesentium quam, et perspiciatis,
                consectetur velit culpa molestias dignissimos
                voluptatum veritatis quod aliquam! Rerum placeat necessitatibus, vitae dolorum`
        }); */
    }

    ngOnInit() {
	    // if(!this.afAuth.getLoginAuth()) {
        //     alert("Authentication Failed.\nPlease Check Administrator for your Authentication.");
        //     this.afAuth.valueClear();
	    //     this.router.navigate(['/login']);
        // }
        
        this.company = this.afAuth.getCompanyName();
        if(this.company)
        {
            localStorage.setItem('company', this.company);
        }
        if(!this.company)
        {
           this.company = localStorage.getItem('company');
        }
    }

    public closeAlert(alert: any) {
        const index: number = this.alerts.indexOf(alert);
        this.alerts.splice(index, 1);
    }
}
