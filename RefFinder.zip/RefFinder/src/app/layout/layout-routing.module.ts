import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '', component: LayoutComponent,
        children: [
            { path: 'home', loadChildren: './home/home.module#HomeModule' },
            { path: 'gamebidlist', loadChildren: './gamebidlist/gamebidlist.module#GamebidlistModule' },
            { path: 'gamelist', loadChildren: './gamelist/gamelist.module#GamelistModule' },
            { path: 'datas', loadChildren: './datas/datas.module#DatasModule' },
            { path: 'graph', loadChildren: './graph/graph.module#GraphModule' },
            { path: 'lost-chk', loadChildren: './lost-chk/lost-chk.module#LostChkModule' },
            { path: 'qna', loadChildren: './qna/qna.module#QnAModule' },
            { path: 'scheduler', loadChildren: './scheduler/scheduler.module#SchedulerModule' },
            { path: 'about', loadChildren: './about/about.module#AboutModule' },
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule { }
