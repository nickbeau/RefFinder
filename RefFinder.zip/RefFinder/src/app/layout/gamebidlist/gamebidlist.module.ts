import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageHeaderModule } from '../../shared';
import { DataTableModule } from 'angular-4-data-table/src/index';
import { DataTableDemo2 } from '../demo2/data-table-demo2';

import { GamebidlistRoutingModule } from './gamebidlist-routing.module';
import { GamebidlistComponent } from './gamebidlist.component';
@NgModule({
  imports: [
    CommonModule, 
    DataTableModule,
    GamebidlistRoutingModule,
    PageHeaderModule
  ],
  declarations: [GamebidlistComponent, DataTableDemo2]
})
export class GamebidlistModule { }
