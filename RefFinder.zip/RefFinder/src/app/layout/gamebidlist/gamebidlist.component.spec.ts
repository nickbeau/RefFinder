import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GamebidlistComponent } from './gamebidlist.component';

describe('GamebidlistComponent', () => {
  let component: GamebidlistComponent;
  let fixture: ComponentFixture<GamebidlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GamebidlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GamebidlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
