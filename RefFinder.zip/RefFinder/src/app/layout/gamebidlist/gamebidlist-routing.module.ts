import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GamebidlistComponent } from './gamebidlist.component';

const routes: Routes = [
  { path: '', component: GamebidlistComponent }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GamebidlistRoutingModule { }
