import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../../shared/service/auth.service';

@Component({
  selector: 'app-gamebidlist',
  templateUrl: './gamebidlist.component.html',
  styleUrls: ['./gamebidlist.component.scss']
})
export class GamebidlistComponent implements OnInit {
  private rows: any[] = [];
  loadingIndicator: boolean = true;
  reorderable: boolean = true;
  constructor(private afAuth: AuthService) { }

  ngOnInit() {
    this.afAuth.getMatchInfo();
    Observable.interval(2000).subscribe(() => this.rows = this.afAuth.getMatchArrayData())
  }

}
