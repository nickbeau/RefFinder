import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../../router.animations';
import { AuthService } from '../../shared/service/auth.service';

@Component({
    selector: 'app-graph',
    templateUrl: './graph.component.html',
    styleUrls: ['./graph.component.scss'],
    animations: [routerTransition()]
})
export class GraphComponent implements OnInit {

    private clubName: string;
    private groundName: string;
    private groupName: string;
    private gameDate: string;
    private gameTime: string;

    constructor(private afAuth: AuthService, private router: Router) { }

    ngOnInit() {
        if (!this.afAuth.getLoginAuth()) {


            /*
            alert("Authentication Failed.\nPlease Check Administrator for your Authentication.");
            this.afAuth.valueClear();
            this.router.navigate(['/login']);*/



        }
        else {

        }
    }

    createGame() {

        this.clubName = (<HTMLInputElement>document.getElementById("email")).value;
        this.groundName = (<HTMLInputElement>document.getElementById("ground")).value;
        this.groupName = (<HTMLInputElement>document.getElementById("age")).value;
        this.gameDate = (<HTMLInputElement>document.getElementById("gameDate")).value;
        this.gameTime = (<HTMLInputElement>document.getElementById("gameTime")).value;

        this.afAuth.register(this.clubName, this.groundName, this.groupName, this.gameDate, this.gameTime);


    }





}
