import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LostChkRoutingModule } from './lost-chk-routing.module';
import { LostChkComponent } from './lost-chk.component';
import { PageHeaderModule } from '../../shared';

@NgModule({
    imports: [
        CommonModule,
        LostChkRoutingModule,
        PageHeaderModule
    ],
    declarations: [LostChkComponent]
})
export class LostChkModule { }
