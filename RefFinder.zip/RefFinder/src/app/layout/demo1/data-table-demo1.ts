import { Component, OnInit } from '@angular/core';
import { DataTableResource } from 'angular-4-data-table';
import { AuthService } from '../../shared/service/auth.service';
import { Observable } from 'rxjs/Observable';


@Component({
    selector: 'data-table-demo-1',
    providers: [],
    templateUrl: './data-table-demo1.html',
    styleUrls: ['./data-table-demo1.css']
})
export class DataTableDemo1 implements OnInit {

    itemResource;
    items = [];
    itemCount = 0;
    private rows: any[] = [];

    constructor(private afAuth: AuthService) {
    }
    ngOnInit() {
        this.afAuth.getMatchInfo();
        Observable.interval(2000).subscribe(() => {
            this.rows = this.afAuth.getMatchArrayData();
            this.items = this.rows;
            this.itemCount = this.rows.length;
        }

        )
    }
    rowClick(rowEvent) {
        console.log('Clicked: ' + rowEvent.row.item.club);
    }

    rowDoubleClick(rowEvent) {
        alert('Double clicked: ' + rowEvent.row.item.club);
    }

}
