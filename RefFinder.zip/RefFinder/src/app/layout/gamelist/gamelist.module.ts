import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageHeaderModule } from '../../shared';
import { DataTableModule } from 'angular-4-data-table/src/index';

import { DataTableDemo1 } from '../demo1/data-table-demo1';

import { GamelistRoutingModule } from './gamelist-routing.module';
import { GamelistComponent } from './gamelist.component';

@NgModule({
  imports: [
    CommonModule,
    GamelistRoutingModule,
    DataTableModule,
    PageHeaderModule
  ],
  declarations: [
    GamelistComponent, DataTableDemo1
  ]
})
export class GamelistModule { }
