import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../shared/service/auth.service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-gamelist',
  templateUrl: './gamelist.component.html',
  styleUrls: ['./gamelist.component.scss']
})
export class GamelistComponent implements OnInit {
  private rows: any[] = [];
  loadingIndicator: boolean = true;
  reorderable: boolean = true;
  constructor(private afAuth: AuthService) { }

  ngOnInit() {
    this.afAuth.getMatchInfo();
    Observable.interval(2000).subscribe(() => this.rows = this.afAuth.getMatchArrayData())

    
  }

}
