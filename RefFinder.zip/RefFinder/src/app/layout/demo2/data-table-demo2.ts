import { Component, OnInit } from '@angular/core';
import { DataTableResource } from 'angular-4-data-table';
import { AuthService } from '../../shared/service/auth.service';
import { Observable } from 'rxjs/Observable';


@Component({
    selector: 'data-table-demo-2',
    providers: [],
    templateUrl: './data-table-demo2.html',
    styleUrls: ['./data-table-demo2.css']
})
export class DataTableDemo2 implements OnInit {

    itemResource;
    items = [];
    itemCount = 0;
    private rows: any[] = [];

    constructor(private afAuth: AuthService) {
    }
    ngOnInit() {
        this.afAuth.getMatchInfoForReferee();
        Observable.interval(2000).subscribe(() => {
            this.rows = this.afAuth.getMatchArrayData1();
            this.items = this.rows;
            this.itemCount = this.rows.length;
        }

        )
    }

    bidgame(item){
        this.afAuth.bidonmatch(item);
    }
    rowClick(rowEvent) {
        console.log('Clicked: ' + rowEvent.row.item.club);
    }

    rowDoubleClick(rowEvent) {
        alert('Double clicked: ' + rowEvent.row.item.club);
    }

}
