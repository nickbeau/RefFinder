import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../service/auth.service';

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
    isActive = false;
    showMenu = '';
    public myClass1 = "show";
    public myClass2 = "show";
  
    private MainTitle = "Game Management";
    constructor(private afAuth: AuthService) { }
    ngOnInit() {
        if(this.afAuth.getCompanyName() == "Game Owner")
        {
            this.myClass1 = "show";
            this.myClass2 = "hide";
            
        }
        else if(this.afAuth.getCompanyName() == "Referee")
        {
            this.myClass1 = "hide";
            this.myClass2 = "show";
        }
        else
        {
            this.myClass1 = "show";
            this.myClass2 = "show";
        }
    }
    eventCalled() {
        this.isActive = !this.isActive;
    }
    addExpandClass(element: any) {
        if (element === this.showMenu) {
            this.showMenu = '0';
        } else {
            this.showMenu = element;
        }
    }
}
