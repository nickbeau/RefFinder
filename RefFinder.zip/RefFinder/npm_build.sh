nohup ng build --prod --output-path=public/ > ~/build_log.txt &
